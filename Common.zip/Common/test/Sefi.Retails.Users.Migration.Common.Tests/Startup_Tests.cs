﻿using Microsoft.Extensions.Configuration;
using Moq;
using System;
using Xunit;

namespace Sefi.Retail.User.Migration.Common.Tests
{
    public class Startup_Tests
    {
        [Fact]
        public void Tests()
        {
            /// Arrange
            Mock<IConfiguration> config = new();

            /// Act
            Startup startup = new(config.Object);
            IConfiguration result = startup.GetConfiguration();

            /// Assert
            Assert.Equal(config.Object, result);

            try
            {
                /// Act
                _ = new Startup(null);
            }
            catch (ArgumentNullException ex)
            {
                /// Assert
                Assert.Equal("Value cannot be null. (Parameter 'configuration')", ex.Message);
            }
        }
    }
}