﻿using Newtonsoft.Json.Linq;
using System;
using Xunit;

namespace Sefi.Retail.User.Migration.Common.Tests
{
    public class JsonExtension_Tests
    {
        [Fact] 
        public void Tests()
        {
            /// Arrange
            var json = JObject.Parse(@"
{
    ""parent"": {
        ""children"": [
            {
                ""child"": { 
                    ""age"": 2, 
                    ""sex"": ""male"",
                    ""birthday"": ""3/18/2022"",
                    ""id"": ""dd43c280-6279-43ee-a838-1e27e8372e89"",
                    ""csection"": false
                }
            }
        ]
    }
}");
            /// Act
            int age = json.Get<int>("parent.children[0].child.age");
            string sex = json.GetNullable<string>("parent.children[0].child.sex", out JValue jval);
            DateTime birthday = json.Get<DateTime>("parent.children[0].child.birthday");
            Guid id = json.GetGuid("parent.children[0].child.id");
            bool csection = json.Get<bool>("parent.children[0].child.csection");

            /// Assert
            Assert.Equal(2, age);
            Assert.Equal("male", sex);
            Assert.Equal(DateTime.Parse("3/18/2022"), birthday);
            Assert.Equal(Guid.Parse("dd43c280-6279-43ee-a838-1e27e8372e89"), id);
            Assert.False(csection);

            /// Arrange
            jval.Parent.Remove();

            /// Act
            sex = json.GetNullable<string>("parent.children[0].child.sex");

            /// Assert
            Assert.Null(sex);
        }
    }
}