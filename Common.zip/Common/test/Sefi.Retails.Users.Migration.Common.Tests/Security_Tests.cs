﻿using Xunit;

namespace Sefi.Retail.User.Migration.Common.Tests
{
    public class Security_Tests
    {
        [Fact]
        public void Tests()
        {
            /// Arrange
            var encrypted = Security.Encrypt("abc");

            /// Act
            var decrypted = Security.Decrypt(encrypted);

            /// Assert
            Assert.Equal("abc", decrypted);

            /// Act
            var encrypted2 = Security.Encrypt("abc");

            /// Assert
            Assert.NotEqual(encrypted, encrypted2);

            /// Act
            encrypted = Security.Encrypt(null);

            /// Assert
            Assert.Empty(encrypted);

            /// Act
            encrypted = Security.Encrypt(string.Empty);

            /// Assert
            Assert.Empty(encrypted);

            /// Assert
            Assert.Equal("abc", Security.Decrypt("abc"));

        }
    }
}