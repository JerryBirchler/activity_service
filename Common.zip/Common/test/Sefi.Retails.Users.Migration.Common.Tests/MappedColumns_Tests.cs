﻿using System;
using Xunit;

namespace Sefi.Retail.User.Migration.Common.Tests
{
    public class MappedColumns_Tests
    {
        public void Tests()
        {
            /// Arrange
            MappedColumns cols = new();
            Guid guid = Guid.NewGuid();
            cols.Add("guid", guid);

            /// Act
            string result = cols["guid"];

            /// Assert
            Assert.Equal(guid.ToString(), result);

            /// Arrange
            DateTime now = DateTime.Parse("2024-03-18 15:30");
            cols.Add("now", now);

            /// Act
            result = cols["now"];

            /// Assert
            Assert.Equal("3/18/2024 3:30:00 PM", result);

            /// Arrange
            decimal number = 3.1415926536M;
            cols.Add("number", number);

            /// Act
            result = cols["number"];

            /// Assert
            Assert.Equal("3.1415926536", result);

            /// Arrange
            bool yes = true;
            cols.Add("yes", yes);

            /// Act
            result = cols["yes"];

            /// Assert
            Assert.Equal("True", result);
        }
    }
}