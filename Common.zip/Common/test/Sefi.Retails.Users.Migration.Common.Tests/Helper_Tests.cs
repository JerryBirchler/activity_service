﻿using System.Collections.Generic;
using Xunit;

namespace Sefi.Retail.User.Migration.Common.Tests
{
    public class Helper_Tests
    {
        public void Tests()
        {
            /// Arrange
            string text = "{{a}}, {{b}}, {{z}}, {{x}}, {y}}, {{c}}";
            SortedSet<string> vars = Helpers.GetVariables(text);
            Dictionary<string, string?> dictionary = new()
            {
                { "a", "aye" },
                { "b", "bee" },
                { "c", "sea" },
                { "z", "zebra" }
            };

            /// Act
            string list = string.Join(',', vars);

            /// Assert
            Assert.Equal("a,b,c,x,z", list);

            try
            {
                /// Act
                _ = Helpers.Interpolate(text, key =>
                {
                    return dictionary[key];
                });
            }
            catch(KeyNotFoundException ex)
            {
                /// Assert
                Assert.Equal("The given key 'x' was not present in the dictionary.", ex.Message);
            }

            /// Arrange
            dictionary.Add("x", "xray");

            /// Act
            string result = Helpers.Interpolate(text, key =>
            {
                return dictionary[key];
            });

            /// Assert
            Assert.Equal("aye, bee, zebra, xray, {y}}, sea", result);

            /// Arrange
            List<string> ordered = new() { "apple", "berry", "avocado", "orange", "banana" };
            int index = 0;

            /// Act
            result = Helpers.Interpolate(text, key =>
            {
                return ordered[index++];
            });

            /// Assert
            Assert.Equal("apple, berry, banana, orange, {y}}, avocado", result);

            /// Arrange
            text = "{{a}}, {{b}}, {{c}}, {{b}}, {y}}, {{a}}";
            index = 0;

            /// Act
            result = Helpers.Interpolate(text, key =>
            {
                return ordered[index++];
            });

            /// Assert
            Assert.Equal("apple, berry, avocado, berry, {y}}, apple", result);

            /// Act
            result = Helpers.Interpolate(text, key =>
            {
                return dictionary[key];
            });

            /// Assert
            Assert.Equal("aye, bee, sea, bee, {y}}, aye", result);
        }
   }
}