﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Moq;
using Sefi.Retail.User.Migration.Common.Models;
using System;
using Xunit;

namespace Sefi.Retail.User.Migration.Common.Tests
{
    public class Configuration_Tests
    {
        [Fact]
        public void Tests()
        {
            try
            {
                /// Act
                _ = new Configuration(null);
            }
            catch(ArgumentNullException ex) 
            {
                /// Assert
                Assert.Equal("Value cannot be null. (Parameter 'config')", ex.Message);
            }

            /// Arrange
            IConfigurationRoot testConfig = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json")
                .Build(); 

            Configuration config = new(testConfig);
            IConfigurationSection envSection = config.GetSection("Environments");

            /// Act            
            var result = Configuration.MatchItem(envSection, "Name", "sandbox");

            /// Assert
            Assert.Equal(-1, result);

            /// Act            
            result = Configuration.MatchItem(envSection, "Name", "stable");

            /// Assert
            Assert.Equal(0, result);

            /// Act            
            result = Configuration.MatchItem(envSection, "Name", "production");

            /// Assert
            Assert.Equal(1, result);

            /// Act            
            var text = config["Environments:0:Name"];

            /// Assert
            Assert.Equal("stable", text);

            /// Act            
            text = config["Environments:2:Name"];

            /// Assert
            Assert.Null(text);

            /// Act            
            Configuration.GetKeyValuePairs(envSection, 0, (key, item) =>
            {
                /// Assert
                Assert.EndsWith(key, item.Key);
            });

            /// Arrange
            IConfigurationSection transSection = config.GetSection("Environments:0:Translations");

            /// Act            
            Configuration.GetKeyValuePairs(transSection, (index, key, item) =>
            {
                /// Assert
                Assert.EndsWith(key, item.Key);
                Assert.True(index >= 0);
            });
        }
    }
}