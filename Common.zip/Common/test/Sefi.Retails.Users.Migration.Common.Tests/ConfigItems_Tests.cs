﻿using Xunit;

namespace Sefi.Retail.User.Migration.Common.Tests
{
    public class ConfigItems_Tests
    {
        [Fact]
        public void Tests()
        {
            /// Arrange
            ConfigItems items = new();
            items.AddSetting("key1", "value1");
            items.AddCommandLine("key1", "value2");

            /// Act
            var key = items["key1"];

            /// Assert
            Assert.Equal("value2", key);

            /// Arrange
            items.AddFile("key1", "value3");

            /// Act
            key = items["key1"];

            /// Assert
            Assert.Equal("value3", key);
            Assert.True(items.ContainsKey("key1"));
            Assert.Single(items.GetKeys());

            /// Act
            items.Add(new ConfigItem("key2", ConfigItems.Source.CommandLine, null));

            /// Assert
            Assert.Single(items.GetKeys());
        }
    }
}