﻿using System.Text;
using System.Security.Cryptography;

namespace Sefi.Retail.User.Migration.Common
{
    public static class Security
    {
        private const int _saltLen = 5;
        private const string PWD_SUFFIX_NEW = "1F3n!%zy";
        private static readonly byte[] IV = new byte[] { 0xf, 0x6f, 0x13, 0x2e, 0x35, 0xc2, 0xcd, 0xf9 };
#pragma warning disable SYSLIB0021
        private static readonly SymmetricAlgorithm _sa = new TripleDESCryptoServiceProvider
        {
            Mode = CipherMode.CBC
        };
#pragma warning restore SYSLIB0021 
        private static byte[] LegalKey = GetLegalKey(_sa);

        static Security()
        {
            _sa.Key = LegalKey;
            _sa.IV = IV;
        }

        public static string Encrypt(string clearText)
        {
            if (clearText == null || clearText.Length == 0)
                return string.Empty;

            byte[] bytes = ASCIIEncoding.ASCII.GetBytes(GenerateSeed2() + clearText + GenerateSeed2());
            _sa.Key = GetLegalKey(_sa);
            _sa.IV = IV;

            using ICryptoTransform transform = _sa.CreateEncryptor();
            using MemoryStream ms = new();
            CryptoStream cs = new(ms, transform, CryptoStreamMode.Write);
            cs.Write(bytes, 0, bytes.Length);
            cs.FlushFinalBlock();
            byte[] encryptedBytes = ms.ToArray();
            return Convert.ToBase64String(encryptedBytes, 0, encryptedBytes.Length);
        }

        private static string GenerateSeed2()
        {
            using var generator = RandomNumberGenerator.Create();
            var salt = new byte[_saltLen];
            generator.GetBytes(salt);
            return ASCIIEncoding.ASCII.GetString(salt);
        }

        public static string Decrypt(string? encrypted)
        {
            if (encrypted == null)
            {
                return string.Empty;
            }
            const int saltLength = 5;
            if (encrypted == null || encrypted.Length == 0)
                return string.Empty;

            string decrypted;
            try
            {
                byte[] bytes = Convert.FromBase64String(encrypted);
                using ICryptoTransform ct = _sa.CreateDecryptor();
                using var ms = new MemoryStream(bytes, 0, bytes.Length);
                var cs = new CryptoStream(ms, ct, CryptoStreamMode.Read);
                var sr = new StreamReader(cs);
                decrypted = sr.ReadToEnd();
                return decrypted[saltLength..^saltLength].Replace("\r\n", ""); ;
            }
            catch (FormatException)
            {
                return encrypted;
            }
            catch (CryptographicException)
            {
                return encrypted;
            }
        }

        private static byte[] GetLegalKey(SymmetricAlgorithm cs)
        {
            string key = PWD_SUFFIX_NEW;
            if (cs.LegalKeySizes.Length > 0)
            {
                var legalKeySize = cs.LegalKeySizes[0];
                int keySize = key.Length * 8;
                int minSize = legalKeySize.MinSize;
                int maxSize = legalKeySize.MaxSize;
                int skipSize = legalKeySize.SkipSize;

                if (keySize > maxSize)
                {
                    key = key[..(maxSize / 8)];
                }
                else if (keySize < maxSize)
                {
                    int validSize = keySize <= minSize
                        ? minSize
                        : keySize - (keySize % skipSize) + skipSize;

                    if (keySize < validSize)
                        key = key.PadRight(validSize / 8, '*');
                }
            }
            return Encoding.ASCII.GetBytes(key);
        }
    }
}
