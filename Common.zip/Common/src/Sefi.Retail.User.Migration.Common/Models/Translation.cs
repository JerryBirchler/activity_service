﻿namespace Sefi.Retail.User.Migration.Common.Models
{
    public class Translation
    {
        public string ColumnName { get; set; } = string.Empty;
        public string From { get; set; } = string.Empty;
        public string To { get; set; } = string.Empty;
        public Type? Type { get; set; } 
        public List<object> Instances = new();
    }
}
