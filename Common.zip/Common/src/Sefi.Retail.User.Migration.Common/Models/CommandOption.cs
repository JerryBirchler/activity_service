﻿namespace Sefi.Retail.User.Migration.Common.Models
{
    public class CommandOptions
    {
        private readonly Dictionary<string, int> _options = new();
        private readonly List<CommandOption> _list = new();
        private readonly List<string> _args = new();
        public void Add(string name, string desc, string example, bool isRequired = true)
        {
            CommandOption option = new(name, desc, example, isRequired);
            _args.Add(option.Key);
            _options[option.Key.ToUpper()] = _list.Count;
            _list.Add(option);
        }

        public bool ContainsKey(string key)
        {
            return _options.ContainsKey(key.ToUpper());
        }
        public IEnumerable<CommandOption> DisplayList
        {
            get
            {
                var list = new List<CommandOption>
                {
                    new CommandOption("KEYWORD", "DESCRIPTION", "EXAMPLE")
                };
                _list.ForEach(option => list.Add(option));
                return list;
            }
        }
        public List<CommandOption> List
        {
            get
            {
                return _list;
            }
        }
        public List<string> Args
        {
            get
            {
                return _args;
            }
        }


        public string? this[string key] 
        { 
            get
            {
                key = key.ToUpper();
                if (!_options.ContainsKey(key))
                    return null; 

                int index = _options[key];
                return _list[index].Value;
            }
            set
            {
                key = key.ToUpper();
                int index = _options[key];
                _list[index].Value = value;
            }
        }
    }

    public class CommandOption
    {
        public CommandOption(string name, string desc, string example, bool isRequired = true) 
        { 
            Key = name.Split('=')[0];
            Name = name;
            Description = desc;
            Example = example;
            IsRequired = isRequired;
        }

        public string Key { get; private set; } = string.Empty;
        public string Name { get; private set; } = string.Empty;
        public string Description { get; private set; } = string.Empty;
        public string Example { get; private set; } = string.Empty;
        public bool IsRequired { get; private set; } = true;
        public string? Value { get; set; }

        public static int DisplayColumns { get { return 3; } }


        public string this[int index]
        {
            get
            {
                switch (index)
                {
                    case 0:
                        return Name;
                    case 1:
                        return Description;
                    case 2:
                        return Example;
                    default:
                        break;
                }
                throw new IndexOutOfRangeException();
            }
        }
    }
}
