﻿using Newtonsoft.Json.Linq;

namespace Sefi.Retail.User.Migration.Common
{
    public static class DictionaryExtensions
    {
        public static string Interpolate(this Dictionary<string, string?> collection, string? original)
        {
            return Helpers.Interpolate(original, key => 
            {
                return collection[key];
            });
        }
    }
    public static class ConfigItemsExtensions
    {
        public static string Interpolate(this ConfigItems vars, string? original)
        {
            return Helpers.Interpolate(original, key =>
            {
                return vars[key];
            });
        }
    }
    public static class MappedColumnsExtensions
    {
        public static string Interpolate(this MappedColumns cols, string? original)
        {
            return Helpers.Interpolate(original, key =>
            {
                return cols[key];
            });
        }
    }
    public static class JObjectExtensions
    {
        public static Guid GetGuid(this JObject? json, string path, out JValue jval)
        {
            jval = GetObject(json, path);
            return json.GetGuid(jval);
        }
        public static Guid GetGuid(this JObject? json, string path)
        {
            JValue value = GetObject(json, path);
            return json.GetGuid(value);
        }
        public static Guid GetGuid(this JObject? json, JValue value)
        {
            if (value.Value == null)
                throw new NullReferenceException();

            return Guid.Parse(value?.Value + string.Empty);
        }
        public static Guid? GetNullableGuid(this JObject? json, string path, out JValue? jval)
        {
            jval = json?.SelectToken(path) as JValue;
            return json.GetNullableGuid(jval);
        }
        public static Guid? GetNullableGuid(this JObject? json, string path)
        {
            JValue? value = json?.SelectToken(path) as JValue;
            return json.GetNullableGuid(value);
        }
        public static Guid? GetNullableGuid(this JObject? json, JValue? value)
        {
            if (value?.Value == null)
                return null;

            return Guid.Parse(value?.Value + string.Empty);
        }
        public static T Get<T>(this JObject? json, string path, out JValue jval) where T : IConvertible
        {
            jval = GetObject(json, path);
            return ConvertTo<T>(jval.Value + string.Empty);
        }
        public static T Get<T>(this JObject? json, string path) where T: IConvertible
        {
            JValue value = GetObject(json, path);
            return ConvertTo<T>(value.Value + string.Empty);
        }
        public static T Get<T>(this JObject? json, JValue value) where T : IConvertible
        {
            if (value.Value == null)
                throw new NullReferenceException();

            return ConvertTo<T>(value.Value + string.Empty);
        }
        public static T? GetNullable<T>(this JObject? json, string path, out JValue? jval) where T : IConvertible
        {
            jval = json?.SelectToken(path) as JValue;
            return json.GetNullable<T>(jval);
        }
        public static T? GetNullable<T>(this JObject? json, string path) where T : IConvertible
        {
            JValue? jval = json?.SelectToken(path) as JValue;
            return json.GetNullable<T>(jval);
        }
        public static T? GetNullable<T>(this JObject? json, JValue? jval) where T : IConvertible
        {
            if (jval == null)
                return default;

            if (jval.Value == null)
                return default;

            return ConvertTo<T>(jval.Value + string.Empty);
        }

        private static JValue GetObject(this JObject? json, string path)
        {
            JValue? value = json?.SelectToken(path) as JValue
                ?? throw new NullReferenceException(path);

            if (value.Value == null)
                throw new NullReferenceException(path);

            return value;
        }
        public static T ConvertTo<T>(this object value)
        {
            return (value is T variable) ? variable : (T)Convert.ChangeType(value, typeof(T));
        }
    }
}