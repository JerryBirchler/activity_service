﻿namespace Sefi.Retail.User.Migration.Common.Interfaces
{
    public abstract class IModel
    {
        public string Id { get; set; } = string.Empty;
    }
}
