﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Npgsql;
using Npgsql.Schema;
using Sefi.Retail.User.Migration.Common.Interfaces;
using Sefi.Retail.User.Migration.Common.Models;
using System.Collections.ObjectModel;

namespace Sefi.Retail.User.Migration.Common
{
    public abstract class ConsoleApp
    {
        private const string _simpleHash = "{0}:{1}";
        private const string _argKey = "Args:{0}";
        private const string _logStamp = "[{0}]{1}{2}";
        private const string _date_format = "yyyy'-'MM'-'dd'T'HH':'mm':'ss.fff";
        private const string _parseException = "Unable to parse command line argument {0}.";
        private const string _mapTo = "MapTo:";
        private const string _model = _mapTo + "Model";
        private const string _instancesRelativeKey = _mapTo + "Instances:";
        private const string _instancesFullKey = ":" + _instancesRelativeKey;
        private const string _period = ".";
        private const string _comma = ", ";
        private const string _plus = "+";
        private const string _dash = "-";
        private const string _blank = " ";
        private const string _pipe = "|";
        private const string _leftPipe = "| ";
        private const string _rightPipe = " |";
        private const string _leftBigPipe = "|  ";
        private const string _rightBigPipe = "  |";
        private static readonly Dictionary<string, string?> Vars = new();
        public static readonly ConfigItems Config = new();
        public static readonly SortedList<string, Translation> Translations = new();

        public void ParseCommandLine(string[] args, CommandOptions commands, Configuration config)
        {
            Config.AddSetting("Title", config.GetRequired<string>("Args:Title"));

            commands.Args.ForEach(key =>
            {
                string? value = config[string.Format(_argKey, key)];
                if (value != null)
                    Config.AddSetting(key, value);
            });

            if (args.Length < commands.List.Count && !commands.Args.Any(name => Config.ContainsKey(name)))
                WriteHelp();

            var anyErrors = false;
            foreach (var arg in args)
            {
                if (arg == "HELP" || arg == "?")
                    WriteHelp();

                else
                {
                    try
                    {
                        ParseArgument(arg, commands);
                    }
                    catch(Exception ex) 
                    {
                        anyErrors = true;
                        WriteLog(ex.Message);
                    }
                }
            }

            if (anyErrors)
                WriteHelp();

            if (commands.List.Any(option => option.IsRequired && option.Value == null && !Config.ContainsKey(option.Key)))
                WriteHelp();

            commands.Args.ForEach(key =>
            {
                string? value = commands[key];
                if (value != null)
                    Config.AddCommandLine(key, value);
            });

        }
        private static bool ParseArgument(string arg, CommandOptions commands)
        {
            var parts = arg.Split('=');
            if (parts.Length == 2 && commands.ContainsKey(parts[0]))
            {
                commands[parts[0]] = parts[1];
                return true;
            }
            throw new ApplicationException(string.Format(_parseException, parts[0]));
        }
        public static void WriteLog(string restOfLine, bool displayFiles = true, bool bannerize = false,
            bool exception = false, bool help = false)
        {
            var time = DateTime.Now.ToString(_date_format);
            restOfLine = bannerize ? _leftBigPipe + restOfLine : restOfLine;
            restOfLine = restOfLine == null ? string.Empty : _comma + restOfLine;
            var line = string.Format(_logStamp, time, restOfLine, help ? string.Empty : _period);

            if (bannerize)
            {
                var banner = Enumerable.Repeat(_dash, time.Length + 4).Aggregate((sum, next) => sum + next) + _plus
                    + Enumerable.Repeat(_dash, line.Length - time.Length - 3).Aggregate((sum, next) => sum + next) + _plus;
                Console.WriteLine(banner);
                Console.WriteLine(line + _rightBigPipe);
                Console.WriteLine(banner);
            }
            else
                Console.WriteLine(line);

            if (exception)
                throw new ApplicationException(restOfLine);

        }
        public void WriteHelpLines(CommandOptions commands)
        {
            const string title = "Command line arguments";
            var overall_width = title.Length + 4;
            var widths = new List<int>();
            for (int i = 0; i < CommandOption.DisplayColumns; i++)
                widths.Add(0);

            foreach (var command in commands.DisplayList)
            {
                for (int i = 0; i < widths.Count; i++)
                {
                    var size = command[i].Length + 2;
                    widths[i] = widths[i] < size ? size : widths[i];
                }
            }

            int width = 1;
            for (int i = 0; i < widths.Count; i++)
                width += widths[i] + 1;

            if (width > overall_width)
                overall_width = width;

            var top_line = _plus + Enumerable.Repeat(_dash, overall_width - 2).Aggregate((sum, next) => sum + next) + _plus;
            var title_line = _leftPipe + title + Enumerable.Repeat(_blank, overall_width - title.Length - 4)
                .Aggregate((sum, next) => sum + next) + _rightPipe;

            var bottom_line = _plus;
            for (int i = 0; i < widths.Count; i++)
                bottom_line += Enumerable.Repeat(_dash, widths[i]).Aggregate((sum, next) => sum + next) + _plus;

            WriteLog(top_line, help: true);
            WriteLog(title_line, help: true);
            WriteLog(bottom_line, help: true);
            foreach (var command in commands.DisplayList)
            {
                var display_line = _pipe;
                for (int i = 0; i < widths.Count; i++)
                {
                    var text = command[i];
                    display_line += _blank + text;
                    display_line += Enumerable.Repeat(_blank, widths[i] - text.Length - 1).Aggregate((sum, next) => sum + next) + _pipe;
                }
                WriteLog(display_line, help: true);
                WriteLog(bottom_line, help: true);
            }

            WriteExample();
            Environment.Exit(-1);
        }
        public abstract void WriteHelp();
        public abstract void WriteExample();

        public static Configuration GetConfiguration
        (
            List<string> requiredConfigs,
            out Configuration config,
            out string envName,
            out int envIndex,
            Action<Configuration> getConfiguartions
        )
        {
            WriteLog("started", false);
            var host = CreateDefaultBuilder().Build();

            using IServiceScope serviceScope = host.Services.CreateScope();
            IServiceProvider provider = serviceScope.ServiceProvider;
            var workerInstance = provider.GetRequiredService<Startup>();
            config = new Configuration(workerInstance.GetConfiguration());

            var varSection = config.GetSection("Variables");
            if (varSection != null)
                Configuration.GetKeyValuePairs(varSection, (index, key, item) =>
                    Vars.Add(key, Security.Decrypt(item.Value)));

            var envSection = config.GetSection("Environments")
                ?? throw new ApplicationException(
                    "A valid Environments array must be configured in the application settings.");

            getConfiguartions(config);

            envName = Config["Environment"];
            envIndex = Configuration.MatchItem(envSection, "Name", envName);
            if (envIndex == -1)
                throw new ApplicationException(
                    string.Format("A valid Environment configuration is missing for enviroment: [{0}].", envName));

            Configuration.GetKeyValuePairs(envSection, envIndex, (key, item) =>
                Config.AddSetting(key, Security.Decrypt(Vars.Interpolate(item.Value))));

            foreach (string name in requiredConfigs)
                if (Config[name] == null)
                    throw new ApplicationException(
                        string.Format("{0} configuration is missing for enviroment: [{1}].", name, envName));

            return new Configuration(workerInstance.GetConfiguration());
        }

        public static void ProcessTranslation(Translation translation, string? columnName,
            int maxIndex, Configuration config, string instancePath)
        {
            if (translation.Type != null)
            {
                for (int i = 0; i <= maxIndex; i++)
                {
                    var instance = config.GetSection(instancePath + i).Get(translation.Type);
                    if (instance != null)
                        translation.Instances.Add(instance);
                }
            }

            translation.ColumnName = columnName ?? string.Empty;
            Translations.Add(string.Format(_simpleHash, translation.ColumnName, translation.From), translation);
        }
        private static IHostBuilder CreateDefaultBuilder()
        {
            return Host.CreateDefaultBuilder()
                .UseEnvironment(Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") ?? "Production")
                .ConfigureAppConfiguration((context, app) => 
                {
                    var env = context.HostingEnvironment;
                    app.AddJsonFile("appsettings.json");
                    app.AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true);
                    app.AddEnvironmentVariables();
                })
                .ConfigureServices(services => services.AddSingleton<Startup>());
        }
        public static MappedColumns MapColumns(NpgsqlDataReader dr, ReadOnlyCollection<NpgsqlDbColumn> columns)
        {
            MappedColumns cols = new();
            columns.ToList().ForEach(column => cols.Add(column.ColumnName, dr[column.ColumnName]));
            foreach (var remap in Translations.Where(remap => remap.Value.Type is null))
            {
                var index = remap.Key.IndexOf(':');
                string columnName = string.Format("{0}", remap.Key[..index] ?? string.Empty);
                string value = index == remap.Key.Length ? string.Empty : remap.Key[(index + 1)..];
                try
                {
                    string? item = dr[columnName].ToString();
                    if (item != null && item == value)
                        cols[columnName] = Config.Interpolate(remap.Value.To);
                }
                catch { }
            }

            return cols;
        }

        public static SortedList<string, T> MapClassInstances<T>(string columnName, NpgsqlDataReader dr) where T : IModel
        {
            var mapKey = string.Format(_simpleHash, columnName, dr[columnName].ToString());
            return MapClassInstances<T>(mapKey);
        }
        public static SortedList<string, T> MapClassInstances<T>(string columnName, string? value) where T : IModel
        {
            var mapKey = string.Format(_simpleHash, columnName, value);
            return MapClassInstances<T>(mapKey);
        }
        public static SortedList<string, T> MapClassInstances<T>(string columnName, Guid value) where T : IModel
        {
            var mapKey = string.Format(_simpleHash, columnName, value);
            return MapClassInstances<T>(mapKey);
        }

        private static SortedList<string, T> MapClassInstances<T>(string mapKey) where T : IModel
        {
            SortedList<string, T> instances = new();
            if (Translations.ContainsKey(mapKey))
            {
                Translations[mapKey].Instances
                    .Where(instance => (instance as T) != null).Cast<T>()
                    .Where(instance => !instances.ContainsKey(instance.Id)).ToList()
                    .ForEach(instance => instances.Add(instance.Id, instance));
            }

            return instances;
        }

        public static string GetSortKeys(string[] sortKeys, MappedColumns cols)
        {
            var SortKeyHash = string.Empty;
            sortKeys.ToList().ForEach(sortKey => SortKeyHash += cols.Get<string>(sortKey) + '\n');
            return SortKeyHash;
        }

        public static void Translate(Configuration config, IConfigurationSection section, 
            Func<string?, Type?> getType)
        {
            int maxIndex = -1;
            string instancePath = string.Empty;
            Translation translation = new();
            Configuration.GetKeyValuePairs(section, (sequence, key, item) =>
            {
                if (key == "Column.Name")
                {
                    ProcessTranslation(translation, item.Value, maxIndex, config, instancePath);
                    maxIndex = -1;
                    translation = new();
                }
                else if (key.StartsWith(_mapTo))
                {
                    if (key == _model)
                        translation.Type = getType(item.Value);

                    else
                    {
                        int pos = item.Key.IndexOf(_instancesFullKey);
                        instancePath = item.Key[..pos] + _instancesFullKey;
                        config[item.Key] = Vars.Interpolate(item.Value);
                        int index = int.Parse(key[_instancesRelativeKey.Length..].Split(':')[0]);
                        maxIndex = index > maxIndex ? index : maxIndex;
                    }
                }
                else if (key == "From")
                    translation.From = Vars.Interpolate(item.Value);

                else if (key == "To")
                    translation.To = Vars.Interpolate(item.Value);
            });
        }
    }
}