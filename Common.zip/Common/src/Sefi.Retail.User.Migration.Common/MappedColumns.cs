﻿namespace Sefi.Retail.User.Migration.Common
{
    public class MappedColumns
    {
        private readonly Dictionary<string, object?> _columns = new();
        public void Add(string key, object? value)
        {
            _columns.Add(key, value);
        }

        public string? this[string name]
        {
            get
            {
                if (!_columns.ContainsKey(name))
                    throw new KeyNotFoundException(name);

                var value = _columns[name];
                return value is string ? value as string : (value ?? string.Empty).ToString();
            }
            set
            {
                if (!_columns.ContainsKey(name))
                    throw new KeyNotFoundException(name);

                _columns[name] = value;
            }
        }
        public T Get<T>(string name) where T : IComparable
        {
            if (!_columns.ContainsKey(name))
                throw new KeyNotFoundException(name);

            var value = _columns[name] ?? throw new ArgumentNullException(name);
            return (value is T variable) ? variable : (T)Convert.ChangeType(value, typeof(T));
        }
        public T? GetNullable<T>(string name) where T : IComparable
        {
            if (!_columns.ContainsKey(name))
                throw new KeyNotFoundException(name);

            var value = _columns[name];
            if (value == null)
                return default;

            return (value is T variable) ? variable : (T)Convert.ChangeType(value, typeof(T));
        }
        public Guid GetGuid(string name)
        {
            if (!_columns.ContainsKey(name))
                throw new KeyNotFoundException(name);

            var value = _columns[name] ?? throw new ArgumentNullException(name);
            return Guid.Parse(value + string.Empty);
        }
        public Guid? GetNullableGuid(string name)
        {
            if (!_columns.ContainsKey(name))
                throw new KeyNotFoundException(name);

            var value = _columns[name];
            return value == null ? null : Guid.Parse(value + string.Empty);
        }
    }
}