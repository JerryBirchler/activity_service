﻿using Microsoft.Extensions.Configuration;

namespace Sefi.Retail.User.Migration.Common
{
    public class Startup
    {
        private readonly IConfiguration _configuration;
        public Startup(IConfiguration configuration)
        {
            _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
        }

        public IConfiguration GetConfiguration()
        {
            return _configuration;
        }
    }
}