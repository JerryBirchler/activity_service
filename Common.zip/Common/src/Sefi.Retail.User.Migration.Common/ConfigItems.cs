﻿namespace Sefi.Retail.User.Migration.Common
{
    public class ConfigItems
    {
        private readonly Dictionary<string, ConfigItem> _configItems = new();
        private const string _hash = "{0}#{1}";

        public void Add(ConfigItem variable)
        {
            if (variable.Value == null)
                return;

            var key = string.Format(_hash, variable.Name, (int)variable.Source);
            if (!_configItems.ContainsKey(key))
                _configItems.Add(key, variable);

            else
                _configItems[key] = variable;
        }
        public void AddSetting(string Name, string Value)
        {
            Add(new ConfigItem(Name, Source.AppSettings, Value));
        }
        public void AddCommandLine(string Name, string Value)
        {
            Add(new ConfigItem(Name, Source.CommandLine, Value));
        }
        public void AddFile(string Name, string Value)
        {
            Add(new ConfigItem(Name, Source.File, Value));
        }

        public bool ContainsKey(string Name)
        {
            foreach (var source in Enum.GetValues(typeof(Source)))
            {
                var key = string.Format(_hash, Name, (int)source);
                if (_configItems.ContainsKey(key))
                    return true;
            }

            return false;
        }

        public string this[string name]
        {
            get
            {
                ConfigItem? ci = null;
                foreach (var source in Enum.GetValues(typeof(Source)))
                {
                    var key = string.Format(_hash, name, (int)source);
                    _configItems.TryGetValue(key, out ConfigItem? configItem);
                    if (configItem != null)
                        ci = configItem;
                }

                if (ci == null)
                    throw new KeyNotFoundException(name);

                return ci.Value;
            }
        }

        public enum Source
        {
            AppSettings = 1,
            CommandLine = 2,
            File = 3
        }

        public SortedSet<string> GetKeys()
        {
            SortedSet<string> keys = new();
            _configItems.Keys.ToList().ForEach(key => keys.Add(key.Split('#')[0]));
            return keys;
        }
    }
    public class ConfigItem
    {
        public string Name { get; private set; }
        public ConfigItems.Source Source { get; private set; }
        public string Value { get; set; }
        public ConfigItem(string name, ConfigItems.Source source, string value)
        {
            Name = name;
            Source = source;
            Value = value;
        }
    }
}