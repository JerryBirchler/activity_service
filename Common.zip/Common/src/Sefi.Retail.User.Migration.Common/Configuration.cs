﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Primitives;

namespace Sefi.Retail.User.Migration.Common
{
    public class Configuration : IConfiguration
    {
        private readonly IConfiguration _configuration;

        public Configuration(IConfiguration config)
        {
            _configuration = config ?? throw new ArgumentNullException(nameof(config));
        }
        public string? this[string key] { get => _configuration[key]; set => _configuration[key] = value; }

        public static int MatchItem(IConfigurationSection section, string name, string value)
        {
            int matchItem = -1;
            string path = section.Path;
            foreach (KeyValuePair<string, string?> item in section.AsEnumerable())
            {
                if (item.Key == path)
                    continue;

                string key = item.Key[(path.Length + 1)..];
                int index = key.IndexOf(':');
                if (index < 0)
                    continue;

                string sequence = key[..index];
                key = key[(index + 1)..];

                if (key == name)
                {
                    if (item.Value != null && item.Value == value)
                    {
                        matchItem = int.Parse(sequence);
                        break;
                    }
                    continue;
                }
            }
            return matchItem;
        }

        public static void GetKeyValuePairs
        (
            IConfigurationSection section,
            int matchItem,
            Action<string, KeyValuePair<string, string?>> doWork
        )
        {
            string path = section.Path;
            foreach (KeyValuePair< string, string?> item in section.AsEnumerable())
            {
                if (item.Key == path)
                    continue;

                string key = item.Key[(path.Length + 1)..];
                int index = key.IndexOf(':');
                if (index < 0)
                    continue;

                string sequence = key[..index];
                key = key[(index + 1)..];

                if (matchItem != -1 && matchItem != int.Parse(sequence))
                    continue;

                if (item.Value != null)
                    doWork(key, item);
            }
        }

        public static void GetKeyValuePairs
        (
            IConfigurationSection section,
            Action<int, string, KeyValuePair<string, string?>> doWork
        )
        {
            string path = section.Path;
            foreach (KeyValuePair<string, string?> item in section.AsEnumerable())
            {
                if (item.Key == path)
                    continue;

                string key = item.Key[(path.Length + 1)..];
                int index = key.IndexOf(':');
                if (index < 0)
                    continue;

                string sequence = key[..index];
                key = key[(index + 1)..];
                if (item.Value != null)
                    doWork(int.Parse(sequence), key, item);
            }
        }

        public static void GetArrayValues
        (
            IConfigurationSection section,
            Action<int, string> doWork
        )
        {
            string path = section.Path;
            foreach (KeyValuePair<string, string?> item in section.AsEnumerable())
            {
                if (item.Key == path)
                    continue;

                string? key = item.Key[(path.Length + 1)..];
                if (key.Contains(':'))
                    continue;

                if (item.Value != null)
                    doWork(int.Parse(key), item.Value ?? string.Empty);
            }
        }

        public IConfigurationSection GetSection(string key)
        {
            return _configuration.GetSection(key);
        }

        public T GetRequired<T>(string name)
        {
            const string message = "{0} value is a required {1} in the application configuration.";
            string? value = GetRequired(name);
            string typeName = typeof(T).Name;
            switch (typeName)
            {
                case "String":
                    if (value == null)
                        throw new ApplicationException(string.Format(message, name, typeName));
                    return (T)(value as object);

                case "Int32":
                    if (value == null || !int.TryParse(value, out _))
                        throw new ApplicationException(string.Format(message, name, typeName));
                    return (T)(int.Parse(value) as object);
            }

            return (T)(value ?? string.Empty as object);
        }

        private string? GetRequired(string name)
        {
            var parts = name.Split(':');
            return _configuration.GetSection(parts[0])?[parts[1]];
        }

        IEnumerable<IConfigurationSection> IConfiguration.GetChildren()
        {
            throw new NotImplementedException();
        }

        IChangeToken IConfiguration.GetReloadToken()
        {
            throw new NotImplementedException();
        }
    }
}