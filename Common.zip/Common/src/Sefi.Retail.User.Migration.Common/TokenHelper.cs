﻿using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Text;
using System.Web;

namespace Sefi.Retail.User.Migration.Common
{
    public class TokenHelper
    {
        private static readonly HttpClient _client = new();
        private const string _authorizationFailed = "Authorization failed attempting to get an access token.";

        public static string? GetToken(string issuer, Guid tenantId, Guid targetApiId, Guid clientId, string clientSecret)
        {
            string url = $"{issuer.TrimEnd('/')}/oauth2/token";
            var credentials = string.Format("{0}:{1}", clientId, clientSecret);
            var encodedCreds = Convert.ToBase64String(Encoding.UTF8.GetBytes(credentials))
                .TrimEnd('=')
                .Replace('+', '-')
                .Replace('/', '_');

            var queryString = new List<KeyValuePair<string, string>>
            {
                { new KeyValuePair<string, string>("grant_type", "client_credentials") },
            };
            var body = new List<KeyValuePair<string, string>>
            {
                { new KeyValuePair<string, string>("scope", $"target-entity:{tenantId} target-entity:{targetApiId}") }
            };
            var headers = new List<KeyValuePair<string, string>>
            {
                { new KeyValuePair<string, string>("Authorization", string.Format("Basic {0}", encodedCreds)) },
                { new KeyValuePair<string, string>("Accept", "application/json") }
            };

            var response = Post(url, queryString, body, headers);
            if (string.IsNullOrWhiteSpace(response) || response.StartsWith("<"))
                throw new ApplicationException(_authorizationFailed);

            var json = JsonConvert.DeserializeObject<JObject>(response) ??
                throw new ApplicationException(_authorizationFailed);

            if (json.ContainsKey("error"))
                throw new ApplicationException(response);

            return json.Get<string>("access_token");
        }

        public static string Post
        (
            string url,
            List<KeyValuePair<string, string>>? queryString = null,
            List<KeyValuePair<string, string>>? body = null,
            List<KeyValuePair<string, string>>? headers = null
        )
        {
            if (url == null)
                throw new ApplicationException("Url cannot be null for HttpClient Post requests.");

            HttpContent? content = body == null ? null : new FormUrlEncodedContent(body);

            bool isFirst = true;
            queryString?.ForEach(pair =>
            {
                url += isFirst ? "?" : "&";
                url += $"{HttpUtility.UrlEncode(pair.Key)}={HttpUtility.UrlEncode(pair.Value)}";
            });

            _client.DefaultRequestHeaders.Clear();
            headers?.ForEach(header => _client.DefaultRequestHeaders.Add(header.Key, header.Value));
            using var response = _client.PostAsync(new Uri(url), content);
            var responseContent = response.Result.Content.ReadAsStringAsync();
            responseContent.Wait();
            return responseContent.Result;
        }
    }
}