﻿using System.Text.RegularExpressions;

namespace Sefi.Retail.User.Migration.Common
{
    public static class Helpers
    {
        const string _varExpression = "{{[a-zA-Z][a-zA-Z0-9.:_]*}}";
        public static SortedSet<string> GetVariables(string data)
        {
            SortedSet<string> list = new();
            MatchCollection matches = Regex.Matches(data, _varExpression, RegexOptions.Multiline);
            matches.ToList().ForEach(match => list.Add(match.Value.Substring(2, match.Length - 4)));
            return list;
        }

        public static string Interpolate(string? original, Func<string, string?> getValue)
        {
            if (original == null)
                throw new ArgumentNullException("Cannot interpolate null data");

            var keys = GetVariables(original);
            while (keys.Count > 0)
            {
                foreach (var key in keys)
                {
                    string keyHash = "{{" + key + "}}";
                    string? value = getValue(key);
                    if (value != null)
                        original = original.Replace(keyHash, value);
                }
                keys = GetVariables(original);
            }
            return original;
        }
    }
}