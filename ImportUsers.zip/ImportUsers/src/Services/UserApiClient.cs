﻿using Flurl;
using Flurl.Http;
using Flurl.Http.Content;
using ImportUsers.Models;
using Microsoft.AspNetCore.Mvc;
using Polly;
using Polly.Retry;
using Sefi.Retail.User.Migration.Common;
using System.Net;

namespace ImportUsers.Services
{
    /// <summary>
    /// Calls the User API
    /// </summary>
    public class UserApiClient 
    {
        private readonly string _issuer;
        private readonly string _userApiUrl;
        private readonly Guid _audience;
        private readonly Guid _tenantId;
        private readonly Guid _clientId;
        private readonly string _clientSecret;

        //public UserApiClient(string issuer, string userApiUrl, Guid audience, Guid tenantId, Guid clientId, string clientSecret) 
        public UserApiClient(ConfigItems config)
        {
            _issuer = config["FusionAuth:Issuer"];
            _userApiUrl = config["UserApi:Url"];
            _audience = Guid.Parse(config["UserApi:ApiAudience"]);
            _tenantId = Guid.Parse(config["FusionAuth:CreatorTenantId"]);
            _clientId = Guid.Parse(config["FusionAuth:ServiceUserClientId"]);
            _clientSecret = config["FusionAuth:ServiceUserClientSecret"];
        }

    public static int[] TransientHttpCodes = new int[]
        {
            (int)HttpStatusCode.RequestTimeout,
            (int)HttpStatusCode.TooManyRequests,
            (int)HttpStatusCode.InternalServerError,
            (int)HttpStatusCode.BadGateway,
            (int)HttpStatusCode.ServiceUnavailable,
            (int)HttpStatusCode.GatewayTimeout
        };

        protected virtual TimeSpan[] WaitDurations() => new[] 
        { 
            TimeSpan.FromSeconds(1), 
            TimeSpan.FromSeconds(3), 
            TimeSpan.FromSeconds(5) 
        };

        public async Task<IActionResult> PutUserAsync(User user)
        {
            string? clientCredentialToken = TokenHelper.GetToken(_issuer, _tenantId, _audience, _clientId, _clientSecret);
            if (clientCredentialToken == null)
            {
                return new UnauthorizedResult();
            }

            AsyncRetryPolicy retryPolicy = Policy
                .Handle<FlurlHttpException>(e => e.StatusCode.HasValue && TransientHttpCodes.Contains(e.StatusCode.Value))
                .Or<FlurlHttpTimeoutException>()
                .WaitAndRetryAsync(WaitDurations());

            string url = _userApiUrl.AppendPathSegment(Url.Encode(user.Id.ToString()));
            //url = "https://localhost:5101/v2/users/" + user.Id.ToString();

            PolicyResult<IFlurlResponse> response = await retryPolicy.ExecuteAndCaptureAsync(() => url
                .WithOAuthBearerToken(clientCredentialToken)
                .PutJsonAsync(user))
                .ConfigureAwait(false);

            return response.Outcome != OutcomeType.Successful ? new BadRequestResult() : new NoContentResult();
        }

        public async Task<User?> GetUserAsync(string email)
        {
            string? clientCredentialToken = TokenHelper.GetToken(_issuer, _tenantId, _audience, _clientId, _clientSecret);
            if (clientCredentialToken == null)
            {
                return null;
            }

            AsyncRetryPolicy retryPolicy = Policy
                .Handle<FlurlHttpException>(e => e.StatusCode.HasValue && TransientHttpCodes.Contains(e.StatusCode.Value))
                .Or<FlurlHttpTimeoutException>()
                .WaitAndRetryAsync(WaitDurations());

            string url = _userApiUrl.AppendPathSegment(Url.Encode(email));

            PolicyResult<IFlurlResponse> response = await retryPolicy.ExecuteAndCaptureAsync(() => url
                .WithOAuthBearerToken(clientCredentialToken)
                .GetAsync())
                .ConfigureAwait(false);

            if (response.Outcome != OutcomeType.Successful)
            {
                return null;
            }

            User user = await response.Result.GetJsonAsync<User>().ConfigureAwait(false);
            return user;
        }

        public async Task<IActionResult> PutUserApplicationsAsync(Guid userid, Guid tenantId, 
            string bodyContent, ApplicationConfig app)
        {
            const string restApi = "{0}/applications";
            Guid clientId = Guid.Parse(app.ClientId);
            string clientSecret = app.Secret;
            string? clientCredentialToken = TokenHelper.GetToken(_issuer, tenantId, _audience, clientId, clientSecret);
            if (clientCredentialToken == null)
            {
                return new UnauthorizedResult();
            }

            AsyncRetryPolicy retryPolicy = Policy
                .Handle<FlurlHttpException>(e => e.StatusCode.HasValue && TransientHttpCodes.Contains(e.StatusCode.Value))
                .Or<FlurlHttpTimeoutException>()
                .WaitAndRetryAsync(WaitDurations());

            string url = _userApiUrl.AppendPathSegment(string.Format(restApi, userid));
            var content = new CapturedJsonContent(bodyContent);

            PolicyResult<IFlurlResponse> response = await retryPolicy.ExecuteAndCaptureAsync(() => url
                .WithOAuthBearerToken(clientCredentialToken)
                .PutAsync(content))
                .ConfigureAwait(false);

            return response.Outcome != OutcomeType.Successful ? new BadRequestResult() : new NoContentResult(); 
        }
    }
}