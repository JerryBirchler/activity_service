﻿using Dasync.Collections;
using ImportUsers.Models;
using ImportUsers.Services;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
using Sefi.Retail.User.Migration.Common;
using Sefi.Retail.User.Migration.Common.Models;

namespace ImportUsers
{
    internal class Program : ConsoleApp
    {
        private static readonly Program Base = new();
        private static readonly CommandOptions _options = LoadOptions();
        private static CommandOptions LoadOptions()
        {
            CommandOptions options = new();
            options.Add("Environment={environment}", "Specify the environment: i.e. stable or production", "ENVIRONMENT=stable");
            options.Add("Directory={path}", "Directory where JSON is written", "DIRECTORY=output");
            options.Add("ParallelCalls={threads}", "Number of work threads", "PARALLELCALLS=20", false);
            return options;
        }
        private static readonly List<string> _requiredConfigs = new()
        {
            "UserApi:Url",
            "UserApi:ApiAudience",
            "FusionAuth:Issuer",
            "FusionAuth:ServiceUserClientId",
            "FusionAuth:ServiceUserClientSecret",
            "FusionAuth:CreatorTenantId"
        };

        public override void WriteHelp()
        {
            WriteHelpLines(_options);

        }
        public override void WriteExample()
        {
            WriteLog("Example call:", help: true);
            WriteLog(@"ImportUsers.exe ENVIRONMENT=stable DIRECTORY=c:\data\migration > c:\logs\migration.log", help: true);
        }

        private static async Task Main(string[] args)
        {
            GetConfiguration(_requiredConfigs, out Configuration config, out string envName, out int envIndex, config =>
                Base.ParseCommandLine(args, _options, config));

            SpecificConfiguration(config, envName, envIndex);
            
            string directory = Config["Directory"];
            int threads = int.Parse(Config["ParallelCalls"]);
            await ProcessJsonFilesAsync(directory, threads);
        }

        private static void SpecificConfiguration(Configuration config, string envName, int envIndex)
        {
            var transSection = config.GetSection(string.Format("Environments:{0}:Translations", envIndex));
            if (transSection != null)
            {
                Translate(config, transSection, modelName =>
                {
                    return Type.GetType(string.Format("ImportUsers.Models.{0}", modelName));
                });
            }
        }

        private static async Task ProcessJsonFilesAsync(string directory, int threads)
        {
            const string _notFound = "User: ['{0}'] not found";
            const string _failedToAddPermissions = "User: ['{0}'] failed to add permissions for application: ['{1}']";
            const string _failedToUpdateUser = "User: ['{0}'] failed to update user in fusionauth for application: ['{1}']";

            var userApiClient = new UserApiClient(Config);
            var dirs = Directory.GetDirectories(directory).Append(directory); 

            foreach (string subdir in dirs)
            {
                string[] files = Directory.GetFiles(subdir, "*.json");

                await files.ToList().ParallelForEachAsync(async file =>
                {
                    try
                    {
                        JObject? json = JObject.Parse(File.ReadAllText(file));
                        Guid userId = json.GetGuid("userId");
                        Guid applicationId = json.GetGuid("applications[0].applicationId");
                        Guid tenantId = json.GetGuid("applications[0].tenantId");
                        string? email = json.GetNullable<string>("email", out JValue? jvEmail);

                        /// Remove this from the payload to prevent getting an 
                        /// error later on when we try to add permissions. We
                        /// just stuck it into the orginal JSON so we could 
                        /// fetch it for use for the Get fusionAuth request.
                        jvEmail?.Parent?.Remove();

                        /// If the user does not exist, there is no point in continuing unless
                        /// we want to add the user. I tested this and it is possible to do so.
                        /// But, that is not consistent with the requirements for import.
                        User? user = await userApiClient.GetUserAsync(userId.ToString())
                            ?? throw new ApplicationException(string.Format(_notFound, userId));

                        /// TODO: It looks like we actually can register applications through the put user method
                        /// Instead of marking the payload as an error when we do not find the application, we could
                        /// assign default permissions in fusionauth to register the application
                        bool isRegistered = user.Applications == null || user.Applications
                            .Any(item => item.ApplicationId == applicationId);

                        string? clientCode = json.Get<string>("applications[0].clientCode", out JValue jvClientCode);
                        jvClientCode?.Parent?.Remove();
                        string bodyContent = json.ToString();

                        /// TODO: got to figure out what tenantId to add permissions based on the clientCode. 
                        /// It's not necessarily as simple as creating a new tenant for every clientCode.
                        /// In the case of SEATEST, can we we assume TESTQA as that tenantId? This can be done
                        /// on a case by case basis if we have to override the GUID generated in IADMIN
                        /// simply because this tenant may already exist. The override of this GUID is handled
                        /// as a "Remap" in the application settings.
                        var appconfigs = MapClassInstances<ApplicationConfig>("applicationid", applicationId);
                        IActionResult? actionResult = await userApiClient.PutUserApplicationsAsync(userId, tenantId,
                            bodyContent, appconfigs.FirstOrDefault().Value);

                        if (actionResult == null || (actionResult as NoContentResult) == null)
                        {
                            throw new ApplicationException(string.Format(_failedToAddPermissions, userId, applicationId));
                        }

                        /// We have to remove any "applications" from ther fusionauth user that don't have any 
                        /// permissions to avoid a bad request from the put method. If we remove applications 
                        /// that DO have permissions, it will actually remove the registration. Conversely, if
                        /// we actually add permissions to a "new" registration, it not only registers the 
                        /// application and adds permissions
                        if (user.Applications != null)
                        {
                            List<Application> fusionAuthApps = new();
                            user.Applications.ToList().ForEach(item => fusionAuthApps.Add(item));
                            List<Application> applications = fusionAuthApps.Where(app => app.Permissions != null).ToList();
                            if (!isRegistered)
                            {
                                applications.Add(NewApplication(applicationId));
                            }
                            user.Applications = applications.ToArray();
                        }
                        else if (!isRegistered)
                        {
                            user.Applications = new Application[1] { NewApplication(applicationId) };
                        }

                        actionResult = await userApiClient.PutUserAsync(user);
                        if (actionResult == null || (actionResult as NoContentResult) == null)
                        {
                            throw new ApplicationException(string.Format(_failedToUpdateUser, userId, applicationId));
                        }

                        File.Move(file, file + ".ok");
                    }
                    catch (Exception ex)
                    {
                        WriteLog(ex.Message);
                        try
                        {
                            JObject? json = JObject.Parse(File.ReadAllText(file));
                            JArray errors = new();
                            var error = new JObject { { "Error", ex.Message } };
                            errors.Add(error);
                            json.Add("Errors", errors);
                            File.WriteAllText(file, json.ToString());
                        }
                        catch { }
                        File.Move(file, file + ".error");
                    }
                }, maxDegreeOfParallelism: threads);
            }
        }

        private static Application NewApplication(Guid applicationId) 
        {
            return new Application
            {
                ApplicationId = applicationId /*,
                Permissions = new Dictionary<string, string[]>
                {
                    {  "default", Array.Empty<string>() }
                }*/
            };
        }
     }
}