﻿using Sefi.Retail.User.Migration.Common.Interfaces;

namespace ImportUsers.Models
{
    public class ApplicationConfig : IModel
    {
        public string ClientId { get; set; } = string.Empty;
        public string Secret { get; set; } = string.Empty;

    }
}