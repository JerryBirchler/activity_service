﻿using Newtonsoft.Json;
using System.Text.Json.Serialization;

namespace ImportUsers.Models
{
    public class UserApplications
    {
        [JsonPropertyName("userId")]
        [JsonProperty("userId")]
        public string? UserId { get; set; }

        [JsonPropertyName("email")]
        [JsonProperty("email")]
        public string? Email { get; set; }

        [JsonPropertyName("applications")]
        [JsonProperty("applications")]
        public UserApplication[] Applications { get; set; } = Array.Empty<UserApplication>();
    }

    public class UserApplication
    {
        [JsonPropertyName("clientCode")]
        [JsonProperty("clientCode")]
        public string? ClientCode { get; set; }
        [JsonPropertyName("applicationId")]
        [JsonProperty("applicationId")]
        public string ApplicationId { get; set; } = string.Empty;

        [JsonPropertyName("tenantId")]
        [JsonProperty("tenantId")]
        public string? TenantId { get; set; }

        [JsonPropertyName("primaryDataGroup")]
        [JsonProperty("primaryDataGroup")]
        public string PrimaryDataGroup { get; set; } = string.Empty;

        [JsonPropertyName("groups")]
        [JsonProperty("groups")]
        public List<UserGroup> Groups { get; set; } = new List<UserGroup>();

    }

    public class UserGroup
    {
        [JsonPropertyName("groupId")]
        [JsonProperty("groupId")]
        public string GroupId { get; set; } = string.Empty;

        [JsonPropertyName("roles")]
        [JsonProperty("roles")]
        public string[] Roles { get; set; } = Array.Empty<string>();

        [JsonPropertyName("deny")]
        [JsonProperty("deny")]
        public string[] Deny { get; set; } = Array.Empty<string>();

        [JsonPropertyName("allow")]
        [JsonProperty("allow")]
        public string[] Allow { get; set; } = Array.Empty<string>();
    }
}