with core_data as 
(
	select
	    c.tenant_id as tenantid
	    ,c.client_code as clientcode
	    ,i.guid as userid
	    ,u.id
	    ,usc.application_code as applicationid
	    ,prd.producer_code as primaryDataGroupid
	    ,case
	    	when usc.search_type = '4' then '*'
	    	else usc.search_group
	    end
	    as datagroupid
	    ,usc.search_type
	    ,i.email
	from iadmin.identities i
	join iadmin.identity_providers ip on i.identity_provider_id = ip.id and ip.identity_provider_value = '{{Retail_Version}}'
	join iadmin.identities_bridge ib on ib.identity_id = i.id
	join iadmin.users u on ib.user_id = u.id and u.expiration_date > now()
	JOIN iadmin.user_search_criteria usc ON usc.user_id = u.id 
	JOIN iadmin.producers prd ON u.producer_id = prd.id
	JOIN iadmin.clients c ON prd.client_id = c.id and c.status = 'A' and prd.status in ('A', 'P')
	where 
	    (usc.application_code = 'SEA')
		and ('{{Email}}' = 'all' or i.email = '{{Email}}')
)
select distinct
    cd.tenantid
    ,cd.clientcode
    ,cd.userid
    ,cd.applicationid
    ,min(cd.primaryDataGroupid) as primaryDataGroupid
    ,cd.datagroupid
    ,cd.search_type
    ,cd.email 
    ,cd.allow
from 
(
	select distinct
	    cd.tenantid
	    ,cd.clientcode
	    ,cd.userid
	    ,cd.applicationid
	    ,cd.primaryDataGroupid
	    ,case when cd.datagroupid = '' then 'all' when cd.datagroupid = '*' then 'all' else cd.datagroupid end	    ,cd.search_type
	    ,cd.email 
	    ,ao.image_location as allow
	from core_data cd
	join iadmin.user_application_options uao on uao.user_id = cd.id 
	join iadmin.application_options ao on 
		ao.id = uao.application_option_id 
	    and ao.application_code = cd.applicationid
		and ao.image_location in ('ContractLookup', 'ClaimLookup', 'DealerStatements', 'Remittance')
		and ao.description {{OptionExpression}}
	union 
	select 
	    cd.tenantid
	    ,cd.clientcode
	    ,cd.userid
	    ,cd.applicationid
	    ,cd.primaryDataGroupid
	    ,case when cd.datagroupid = '' then 'all' when cd.datagroupid = '*' then 'all' else cd.datagroupid end
		,cd.search_type
	    ,cd.email 
	    ,usv.security_code as allow
	from core_data cd
	join iadmin.user_security_variables usv on usv.user_id = cd.id
	join iadmin.security_variables sv on usv.security_code = sv.security_code and TRIM(sv.application_code) = cd.applicationid
) as cd 
group by tenantid, clientcode, userid, applicationid, datagroupid, search_type, email, allow
order by tenantid, clientcode, userid, applicationid, datagroupid, search_type, email, allow