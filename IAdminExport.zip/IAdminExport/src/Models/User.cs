﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace IAdminExport.Models
{
    [Serializable]
    public class User
    {
        [JsonPropertyName("applications")]
        [JsonProperty("applications")]
        public Application[] Applications { get; set; } = Array.Empty<Application>();

        [JsonPropertyName("id")]
        [JsonProperty("id")]
        public Guid? Id { get; set; }

        [JsonPropertyName("active")]
        [JsonProperty("active")]
        public bool? Active { get; set; }

        [JsonPropertyName("password")]
        [JsonProperty("password")]
        public string? Password { get; set; }

        [JsonPropertyName("email")]
        [JsonProperty("email")]
        [EmailAddress]
        public string? Email { get; set; }

        [JsonPropertyName("firstName")]
        [JsonProperty("firstName")]
        public string? FirstName { get; set; } = string.Empty;

        [JsonPropertyName("lastName")]
        [JsonProperty("lastName")]
        public string? LastName { get; set; } = string.Empty;

        [JsonPropertyName("data")]
        [JsonProperty("data")]
        public IDictionary<string, object> Data { get; set; } = new Dictionary<string, object>();

    }

    [Serializable]
    public class Application
    {
        [JsonPropertyName("applicationId")]
        [JsonProperty("applicationId")]
        public Guid ApplicationId { get; set; }

        [JsonPropertyName("permissions")]
        [JsonProperty("permissions")]
        public Dictionary<string, string[]> Permissions { get; set; } = new Dictionary<string, string[]>();
    }
}
