﻿using IAdminExport.Models;
using Newtonsoft.Json.Linq;
using Npgsql;
using Npgsql.Schema;
using Sefi.Retail.User.Migration.Common;
using Sefi.Retail.User.Migration.Common.Models;
using System.Collections.ObjectModel;

namespace IAdminExport
{
    internal class Program : ConsoleApp
    {
        private static readonly Program Base = new();
        private static int _fileNo = 0;
        private static readonly CommandOptions _options = LoadOptions();
        private const string _jsonFile = "{0}\\{1}.json";
        private const string _appId = "{{applicationId}}";
        private static string? _directory = string.Empty;
        private static CommandOptions LoadOptions()
        {
            CommandOptions options = new();
            options.Add("Environment={environment}", "Specify the environment: i.e. stable or production", "ENVIRONMENT=stable");
            options.Add("Directory={path}", "Directory where JSON is written", "DIRECTORY=output");
            options.Add("Email={email}", "Limit export by email address", "EMAIL=jbirchler@se-fi.com", false);
            return options;
        }
        private static readonly List<string> _requiredConfigs = new()
        {
            "ConnectionString",
            "Retail_Version",
            "Email",
            "OptionExpression"
        };

        public override void WriteHelp()
        {
            WriteHelpLines(_options);
        }
        public override void WriteExample()
        {
            WriteLog("Example call:", help: true);
            WriteLog(@"IAdminExport.exe ENVIRONMENT=stable DIRECTORY=c:\IAdminExport\ExportedUsers > c:\logs\IAdminExport.log", 
                help: true);
        }

        private static void Main(string[] args)
        {
            GetConfiguration(_requiredConfigs, out Configuration config, out string envName, out int envIndex, config =>
                Base.ParseCommandLine(args, _options, config));

            SpecificConfiguration(config, envName, envIndex);

            _directory = Config["Directory"];
            int pos = _directory.IndexOf("{{");
            _directory = pos >= 0 ? _directory[..pos] : _directory;

            Directory.GetDirectories(_directory).Append(_directory).ToList()
                .ForEach(dir => Directory.GetFiles(dir, "*.json").ToList()
                .ForEach(file => File.Delete(file)));

            CreateExportUserJsonFiles();
        }

        private static void SpecificConfiguration(Configuration config, string envName, int envIndex)
        {
            var dataSection = config.GetSection("Dataset:SortKeys")
                ?? throw new ApplicationException(
                    "A valid Dataset:SortKeys section must be configured in the application settings.");

            var sortKeys = new SortedList<int, string>();
            Configuration.GetArrayValues(dataSection, (index, value) => sortKeys.Add(index, value));
            Config.AddSetting("Dataset:SortKeys", string.Join(',', sortKeys.Values));

            var transSection = config.GetSection(string.Format("Environments:{0}:Translations", envIndex));
            if (transSection != null)
            {
                Translate(config, transSection, modelName => 
                {
                    return Type.GetType(string.Format("IAdminExport.Models.{0}", modelName));
                });
            }

            var sql = File.ReadAllText("Sql\\source.sql");
            Config.AddFile("source.sql", Config.Interpolate(sql));
        }

        private static void CreateExportUserJsonFiles()
        {
            var prevSortKeyHash = string.Empty;
            var prevDataGroup = string.Empty;
            string[] sortKeys = Config["Dataset:SortKeys"].Split(',');
            string connectionString = Config["ConnectionString"];
            string query = Config["source.sql"];
            using var connection = new NpgsqlConnection(connectionString);
            connection.Open();
            var command = new NpgsqlCommand(query, connection);
            NpgsqlDataReader dr = command.ExecuteReader();
            ReadOnlyCollection<NpgsqlDbColumn> columns = dr.GetColumnSchema();
            SortedList<string, ApplicationConfig> appconfigs = new();
            UserApplications userApplications = new();
            List<UserGroup> groups = new();
            List<string> allow = new();

            while (dr.Read())
            {
                /// read the IAdmin data and map its columns into our variable pool
                /// where we will will use remapping to collection application configuration
                MappedColumns cols = MapColumns(dr, columns);
                appconfigs = MapClassInstances<ApplicationConfig>("applicationid", dr);
                string dataGroup = cols.Get<string>("datagroupid");

                string SortKeyHash = GetSortKeys(sortKeys, cols);
                if (prevSortKeyHash != SortKeyHash)
                {
                    if (prevSortKeyHash != string.Empty)
                        WriteJsonFiles(appconfigs, userApplications, groups, allow);

                    prevSortKeyHash = SortKeyHash;
                    prevDataGroup = dataGroup;
                    userApplications = new UserApplications
                    {
                        UserId = cols.GetNullableGuid("userid")?.ToString(),
                        Email = cols.GetNullable<string>("email"),
                        Applications = new List<UserApplication> 
                        {
                            new UserApplication
                            {
                                ApplicationId = string.Empty,
                                ClientCode = cols.GetNullable<string>("clientcode"),
                                TenantId = cols.GetGuid("tenantid").ToString(),
                                PrimaryDataGroup = cols.Get<string>("primarydatagroupid")
                            }
                        }.ToArray()
                    };
                    groups = new()
                    {
                        {
                            new UserGroup
                            {
                                GroupId = dataGroup
                            }
                        }
                    };
                    allow = new();
                }
                else if (prevDataGroup != dataGroup)
                {
                    groups.Last().Allow = allow.ToArray();
                    groups.Add(new UserGroup
                    {
                        GroupId = dataGroup
                    });
                    allow = new();
                    prevDataGroup = dataGroup;
                }

                allow.Add(cols.Get<string>("allow"));
            }

            connection.Close();
            if (appconfigs.Count > 0)
                WriteJsonFiles(appconfigs, userApplications, groups, allow);

            WriteLog(string.Format("Wrote {0} files", _fileNo));
        }

        private static void WriteJsonFiles(SortedList<string, ApplicationConfig> appConfigs, 
            UserApplications userApplications, List<UserGroup> groups, List<string> allow)
        {
            groups.Last().Allow = allow.ToArray();
            userApplications.Applications[0].Groups = groups;

            foreach (ApplicationConfig appConfig in appConfigs.Values)
            {
                string directory = _directory?.Replace(_appId, appConfig.Id) ?? throw new ArgumentNullException();
                
                if (!Directory.Exists(directory))
                    Directory.CreateDirectory(directory);

                var path = string.Format(_jsonFile, directory, ++_fileNo);
                userApplications.Applications[0].ApplicationId = appConfig.Id;
                File.WriteAllText(path, JObject.FromObject(userApplications).ToString());
            }
        }
    }
}